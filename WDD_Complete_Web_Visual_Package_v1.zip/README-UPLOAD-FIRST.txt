WEBSITE DESIGN DOGS — COMPLETE WEB VISUAL PACKAGE v1.0

Repository:
lacreativodesign/website-design-dogs-website

UPLOAD:
Copy the included public/ folders into the repository root.
The references/ folder is for Codex/design comparison only and should not be publicly served.

PRODUCTION ASSETS INCLUDED:
- Final approved logos
- Transparent mascot
- Favicons and app icons
- 8 service icons
- 6 light/dark backgrounds
- 10 coordinated light/dark page scene pairs
- 2 Open Graph images
- 12 clearly labeled portfolio concept thumbnails
- 4 industry campaign hero pairs
- Complete asset manifest

REFERENCE MATERIAL INCLUDED:
- Approved dark page-board mockup
- Approved light page-board mockup
- Approved homepage mockups
- 20 cropped page reference images

IMPORTANT:
- Do not rename files after Codex begins implementation.
- Dark theme is the default.
- Light/dark scene files are coordinated pairs.
- Portfolio concept images must be displayed as concept work, never as real client projects.
- Website Design Dogs is a service brand of LA CREATIVO GROUP, LLC.
